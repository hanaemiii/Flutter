// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<StatefulWidget> createState() {
    return _HomePageState();
  }
}

class _HomePageState extends State<HomePage> {
  Color bgColor = const Color(0xffFCFCFC);
  Color appBlack = const Color(0xff212C2E);
  Color appOrange = const Color(0xffFF6F52);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: bgColor,
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  'ԳՈՌ',
                  style: TextStyle(
                      color: appBlack,
                      fontSize: 20,
                      fontWeight: FontWeight.bold),
                ),
                Icon(Icons.chevron_right_outlined, color: appBlack)
              ],
            ),
            Text(
              'էքսպերտ',
              style: TextStyle(color: appBlack, fontSize: 10),
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.notifications_outlined,
              color: appBlack,
            ),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.search,
              color: appBlack,
            ),
          ),
        ],
        leading: Container(
          margin: EdgeInsets.all(10),
          decoration: const BoxDecoration(
            color: Color(0xffF3F5F5),
            shape: BoxShape.circle,
          ),
          child: IconButton(
            iconSize: 20,
            onPressed: () {},
            icon: const Icon(
              Icons.person,
              color: Color(0xff37424A),
            ),
          ),
        ),
      ),
      body: body(),
    );
  }

  Widget body() {
    return SingleChildScrollView(
      child: Column(
        children: [
          balance(),
          services(),
          servicesGrey(),
          choosed(),
        ],
      ),
    );
  }

  Widget balance() {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Container(
              padding: EdgeInsets.all(15),
              height: 160,
              decoration: BoxDecoration(
                color: Color(0xffF3F5F5),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: const [
                      Icon(Icons.remove_red_eye_sharp),
                    ],
                  ),
                  Text('Հաշվեկշիռ'),
                  Text('0.00 Դ'),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(
                            backgroundColor: appOrange,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(50),
                            ),
                          ),
                          child: Text(
                            'Համալրել',
                            style: TextStyle(fontSize: 15),
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
          SizedBox(
            width: 20,
          ),
          Expanded(
            child: Container(
                padding:
                    EdgeInsets.only(left: 15, right: 15, top: 23, bottom: 23),
                height: 160,
                decoration: BoxDecoration(
                  color: Color(0xff6FD8FF),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'VISA | TELCELL',
                        style: TextStyle(
                          fontSize: 9.75,
                          color: Color(0xffffffff),
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Inter',
                        ),
                      ),
                      //Expanded(
                      Container(
                        decoration: BoxDecoration(
                            //color: Color(0x93282a2b),
                            ),
                        width: 50,
                        height: 60,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Icon(Icons.square,
                                    size: 30, color: Color(0xffffffff)),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Icon(Icons.square, color: Color(0xffffffff)),
                              ],
                            ),
                          ],
                        ),
                      ),
                      //),
                      Text(
                        'ՇՈՒՏՈՎ',
                        style: TextStyle(
                          fontSize: 12,
                          color: Color(0xffffffff),
                          fontFamily: 'Inter',
                        ),
                      ),
                    ])),
          ),
        ],
      ),
    );
  }

  Widget services() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Container(
        padding: EdgeInsets.only(left: 20, right: 10, top: 15, bottom: 15),
        child: Row(
          children: [
            serviceItem(
                title: 'transport',
                subtitle: 'uxetomser',
                bgColor: Color(0xff27C3A4),
                imageURL:
                    'https://www.clker.com/cliparts/l/I/e/m/O/i/purple-bus.svg.hi.png'),
            serviceItem(
                title: 'iventner',
                bgColor: Color(0xffAE98C8),
                imageURL:
                    'https://pnghq.com/wp-content/uploads/2023/02/download_disco_ball_transparent_png_4227.png'),
            serviceItem(
                title: 'terminalic',
                bgColor: appOrange,
                imageURL:
                    'https://clipart-library.com/2023/cute-piggy-bank-clipart-md.png'),
            serviceItem(
                title: 'vark',
                bgColor: Color(0xffAE98C8),
                imageURL:
                    'https://drivenbybattat.com/wp-content/uploads/WH1121_DP_E.png'),
            serviceItem(title: '', bgColor: Colors.amber, imageURL: ''),
            serviceItem(title: '', bgColor: Colors.cyan, imageURL: ''),
            serviceItem(title: '', bgColor: Colors.yellow, imageURL: ''),
          ],
        ),
      ),
    );
  }

  Widget serviceItem(
      {required String title,
      String? subtitle,
      required Color bgColor,
      required dynamic imageURL}) {
    return Container(
      margin: EdgeInsets.only(right: 9),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(10),
      ),
      width: 75,
      height: 90,
      padding: EdgeInsets.all(5),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(title,
                  style: TextStyle(fontSize: 12, color: Color(0xffffffff))),
            ],
          ),
          // Text(subtitle),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              serviceImg(imageURL),
            ],
          ),
        ],
      ),
    );
  }

  Widget serviceImg(dynamic url) {
    return Image(image: NetworkImage(url), width: 50);
  }

  Widget servicesGrey() {
    return Container(
      padding: EdgeInsets.only(left: 22, right: 15, top: 15, bottom: 15),
      child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Tsarayutyunner', style: TextStyle(fontSize: 20)),
                Text('ditel bolory'),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              serviceItemGrey(
                icon: Icons.money,
                title: 'vcharum',
              ),
              serviceItemGrey(
                icon: Icons.arrow_forward_sharp,
                title: 'Poxancum',
              ),
              serviceItemGrey(
                icon: Icons.bus_alert,
                title: 'Transport',
              ),
              serviceItemGrey(
                icon: Icons.plus_one,
                title: 'Vark',
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget serviceItemGrey({required dynamic icon, required String title}) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0xffF3F5F5),
        borderRadius: BorderRadius.circular(10),
      ),
      width: 75,
      height: 90,
      padding: EdgeInsets.all(10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Icon(
                icon,
                color: appOrange,
              ),
            ],
          ),
          Row(
            // mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(title,
                  style: TextStyle(fontSize: 12, color: Color(0xff000000))),
            ],
          ),
          // Text(subtitle),
        ],
      ),
    );
  }

  Widget choosed() {
    return Container(
      padding: EdgeInsets.only(left: 22, right: 15, top: 0, bottom: 15),
      child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Yntrvac', style: TextStyle(fontSize: 20)),
                Text('ditel bolory'),
              ],
            ),
          ),
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(4),
                decoration: const BoxDecoration(
                  color: Color(0xffF3F5F5),
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  iconSize: 25,
                  onPressed: () {},
                  icon: const Icon(
                    Icons.add,
                    color: Color(0xff37424A),
                  ),
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text('Avelacnel', style: TextStyle(fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }
}
